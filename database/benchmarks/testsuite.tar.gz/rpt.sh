clear
 echo "READS:";tail -25 sysbench_mysql_read.txt; echo "WRITES:";tail -25  sysbench_mysql_write.txt
